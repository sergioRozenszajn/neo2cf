sap.ui.define([
	"my/app/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
